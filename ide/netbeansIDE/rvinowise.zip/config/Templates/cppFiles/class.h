#pragma once


class ${CLASSNAME} {
public:
	${CLASSNAME}();
	${CLASSNAME}(const ${CLASSNAME}& orig);
	virtual ~${CLASSNAME}();
private:

};



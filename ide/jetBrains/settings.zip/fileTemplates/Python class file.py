

class ${Name}:
    """

    """
    def __init__(self):
        print("${Name} __init__")
        
        